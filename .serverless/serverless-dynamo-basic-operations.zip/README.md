# serverless-dynamo-basic-operations
This code is for the video tutorial called: "Basic operations with DynamoDB", you can check the instructions on for this code in that video.

[![Basic operations with DynamoDB | Serverless | FooBar](https://img.youtube.com/vi/EzgyTzJll5U/0.jpg)](https://youtu.be/EzgyTzJll5U "Basic operations with DynamoDB  | Serverless | FooBar")

You can check my youtube channel for more serverless videos:  [Foobar Youtube Channel](https://www.youtube.com/foobar-codes).
